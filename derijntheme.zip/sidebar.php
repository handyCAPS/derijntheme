<ul>
	<li><a href="#">Aanbieding</a></li>
	<li><a href="#">Acties</a></li>
	<li><a href="#">Smurfen</a></li>
	<li>
		<table>
			<thead>Openingstijden</thead>
			<tr>
				<td>Maandag</td>
				<td>12:00 - 18:00</td>
				<td>Afpraak</td>
			</tr>
			<tr>
				<td>Dinsdag</td>
				<td>9:00 - 18:00</td>
				<td>Afspraak</td>
			</tr>
			<tr>
				<td>Wo t/m Za</td>
				<td>9:00 - 18:00</td>
				<td>Zonder Afspraak</td>
			</tr>
		</table>
	</li>
	<li>
		<img src="http://lorempixel.com/300/420/fashion
		" alt="Placeholder">
	</li>
</ul>